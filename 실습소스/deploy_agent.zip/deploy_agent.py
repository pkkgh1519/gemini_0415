# pip install google-cloud-aiplatform[reasoningengine,langchain] langgraph
# pip install langchain-google-vertexai

import vertexai
from vertexai.preview import reasoning_engines

# 1. 환경 설정
PROJECT_ID = "byounghwa-go"  # 실제 프로젝트 ID로 수정
LOCATION = "us-central1"
STAGING_BUCKET = f"gs://{PROJECT_ID}-byounghwa-go-agent-engine-bucket" # 이미 존재하는 버킷이어야 함

vertexai.init(project=PROJECT_ID, location=LOCATION, staging_bucket=STAGING_BUCKET)

# 2. 에이전트 클래스 정의 (가장 안전한 구조)
class SafeAgent:
    def __init__(self, project: str, location: str):
        # __init__ 안에는 문자열, 숫자 등 아주 단순한 데이터만 넣어야 에러가 안 납니다.
        self.project = project
        self.location = location

    def set_up(self):
        # [중요] 실제 무거운 라이브러리 로드는 서버에서 실행되는 set_up 안에서 수행합니다.
        from langchain_google_vertexai import ChatVertexAI
        self.model = ChatVertexAI(model_name="gemini-2.5-flash")

    def query(self, input: str):
        response = self.model.invoke(input)
        return response.content  # 답변 텍스트만 추출해서 반환

# 3. 배포 실행
print("에이전트 배포를 시작합니다. 약 3분 정도 소요됩니다...")

try:
    remote_agent = reasoning_engines.ReasoningEngine.create(
        SafeAgent(project=PROJECT_ID, location=LOCATION),
        requirements=[
            "google-cloud-aiplatform[reasoningengine]",
            "langchain-google-vertexai",
            "langchain",
        ],
        display_name="Gemini_Agent_v1",
    )
    print("\n" + "="*50)
    print("배포 성공!")
    print(f"에이전트 리소스 이름: {remote_agent.resource_name}")
    print("="*50)

    # 4. 즉시 테스트
    print("\n테스트 질문 전송 중...")
    response = remote_agent.query(input="A2A 프로토콜에 대해 짧게 설명해줘.")
    print(f"응답 결과: {response}")

except Exception as e:
    print(f"\n배포 중 오류 발생: {e}")
    
# 약 3분 정도 소요