from vertexai.preview import reasoning_engines

# 배포된 에이전트 불러오기 (배포 시 얻은 ID 사용)
agent_resource = "projects/810458263508/locations/us-central1/reasoningEngines/5022402539669159936"
remote_agent = reasoning_engines.ReasoningEngine(agent_resource)

# 에이전트 실행
response = remote_agent.query(input="A2A 프로토콜의 장점이 뭐야?")
print(response)