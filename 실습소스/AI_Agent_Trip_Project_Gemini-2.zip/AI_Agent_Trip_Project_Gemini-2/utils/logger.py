"""
로깅 유틸리티 모듈
에이전트 실행 중 발생하는 로그를 관리합니다.
"""

import logging
import sys
import tempfile
from datetime import datetime
from pathlib import Path


def setup_logger(name: str = "travel_agent", log_level: int = logging.INFO) -> logging.Logger:
    """
    로거를 설정하고 반환합니다.
    
    Args:
        name: 로거 이름
        log_level: 로그 레벨 (기본값: INFO)
    
    Returns:
        설정된 로거 객체
    """
    logger = logging.getLogger(name)
    logger.setLevel(log_level)
    
    # 중복 핸들러 방지
    if logger.handlers:
        return logger
    
    # 콘솔 핸들러
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(log_level)
    
    # 프로젝트 폴더에 두면 Streamlit 파일 감시가 로그 쓰기마다 앱을 리런시켜
    # 동일 버튼 동작이 반복될 수 있음 → 시스템 임시 디렉터리 사용
    log_dir = Path(tempfile.gettempdir()) / "ai_travel_agent_logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"{name}_{datetime.now().strftime('%Y%m%d')}.log"
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    
    # 포맷터 설정
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    console_handler.setFormatter(formatter)
    file_handler.setFormatter(formatter)
    
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    
    return logger


# 전역 로거 인스턴스
logger = setup_logger()

